const BannerPost = () => {
  return (
    <div
      className="sidebar-banner-add"
      style={{ backgroundImage: "url(/images/blog/ad-bg.jpg)" }}
    >
      <div className="banner-content">
        <h4>
          Banner Advertise <br />
          Heading
        </h4>
        <p>From its medieval origins digital</p>
        <a href="#" className="btn-twentyOne fw-500 tran3s">
          Download
        </a>
      </div>
    </div>
  );
};

export default BannerPost;

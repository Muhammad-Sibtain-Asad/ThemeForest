const Tag = () => {
  return (
    <ul className="d-flex tags style-none pb-20">
      <li>Tag:</li>
      <li>
        <a href="#">business</a>,
      </li>
      <li>
        <a href="#">makreting</a>,
      </li>
      <li>
        <a href="#">tips</a>
      </li>
    </ul>
  );
};

export default Tag;

const Address = () => {
  return (
    <div className="col-lg-3 col-sm-4 mb-30">
      <h5 className="footer-title text-white fw-500">Address</h5>
      <p>
        2190 Mirpur terrace, Lake view <br />
        house state, 10 no road.
      </p>
    </div>
  );
};

export default Address;

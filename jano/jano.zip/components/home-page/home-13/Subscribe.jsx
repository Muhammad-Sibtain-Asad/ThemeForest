const Subscribe = () => {
  return (
    <form className="position-relative">
      <input type="email" placeholder="Enter your email" required />
      <button type="submit" className="tran3s fw-500 position-absolute">
        Sign Up
      </button>
    </form>
  );
};

export default Subscribe;

import Insurance from "./home/insurance/page";
export const metadata = {
  title: "Insurance || Jano - Creative Multipurpose React NextJS Template",
};
const MainRoot = () => {
  return <Insurance />;
};

export default MainRoot;

/** @type {import('next').NextConfig} */
const nextConfig = {
    trailingSlash: true,
};

export default nextConfig;
